package com.company;

public class Student {
	String stdName;
	int stdID;
	int noOfSubjects;
	String stdEmail;

	// Create Default constructor
	public Student() {
		this.stdName = "deafult name";
		this.stdID = 0;
		this.noOfSubjects = 0;
		this.stdEmail = "studentname@gmail.com";

	}

	public void showStudentDetails() {
		System.out.println("Student Name :" + this.stdName);
		System.out.println("Student ID :" + this.stdID);
		System.out.println("Student No Of Subjects :" + this.noOfSubjects);
		System.out.println("Student Email :" + this.stdEmail);
	}

}
