package com.company;

public class SixthProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student std1 = new Student();
		
		std1.showStudentDetails();
		
		
	}

}
